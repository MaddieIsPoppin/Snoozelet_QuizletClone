import { NextResponse } from "next/server";
import { isHostedWithoutDatabase, queryOne } from "@/lib/db";

export const runtime = "nodejs";

export async function GET() {
  if (isHostedWithoutDatabase()) {
    return NextResponse.json(
      {
        ok: false,
        database: "unavailable"
      },
      { status: 503 }
    );
  }

  try {
    const result = await queryOne("SELECT 1 AS ok");
    return NextResponse.json({
      ok: true,
      database: result?.ok === 1 ? "connected" : "unavailable"
    });
  } catch {
    return NextResponse.json(
      {
        ok: false,
        database: "unavailable"
      },
      { status: 503 }
    );
  }
}
