"use client";

import { useEffect, useMemo, useRef, useState } from "react";
import { shuffle } from "@/lib/collections";
import useReviewSaver from "@/hooks/useReviewSaver";
import XpNotice from "@/components/XpNotice";

function normalize(value) {
  return String(value || "")
    .trim()
    .toLowerCase()
    .replace(/\s+/g, " ");
}

function buildOptions(card, cards, answerDirection) {
  const correct =
    answerDirection === "definition"
      ? card.definition
      : card.term;

  const alternatives = cards
    .filter((item) => item.id !== card.id)
    .map((item) =>
      answerDirection === "definition"
        ? item.definition
        : item.term
    )
    .filter(
      (value) =>
        normalize(value) !== normalize(correct)
    );

  return shuffle([
    correct,
    ...shuffle(alternatives).slice(0, 3),
  ]);
}

export default function BlastGame({
  deck,
  cards = [],
}) {
  const { saveReview, xpNotice } = useReviewSaver({ mode: "multiple", answerDirection: "definition", grading: "lenient" });
  const [mounted, setMounted] = useState(false);

  const [gameStarted, setGameStarted] = useState(false);
  const [gameOver, setGameOver] = useState(false);

  const [answerDirection, setAnswerDirection] =
    useState("definition");

  const [queue, setQueue] = useState([]);
  const [currentIndex, setCurrentIndex] = useState(0);

  const [score, setScore] = useState(0);
  const [combo, setCombo] = useState(0);
  const [bestCombo, setBestCombo] = useState(0);

  const [lives, setLives] = useState(3);

  const [correctCount, setCorrectCount] = useState(0);
  const [wrongCount, setWrongCount] = useState(0);

  const [feedbackId, setFeedbackId] = useState(null);
  const [feedbackType, setFeedbackType] = useState(null);

  const [locked, setLocked] = useState(false);

  const [timeLeft, setTimeLeft] = useState(6000);
  const [baseTime, setBaseTime] = useState(8);
  const [betweenQuestions, setBetweenQuestions] = useState(900);
  const [startingLives, setStartingLives] = useState(3);
  const [speedUp, setSpeedUp] = useState(true);

  const timerRef = useRef(null);
  const roundStartedRef = useRef(null);

  useEffect(() => {
    setMounted(true);

    return () => {
      if (timerRef.current) {
        window.clearInterval(timerRef.current);
      }
    };
  }, []);

  const currentCard = queue[currentIndex];

  const prompt =
    currentCard
      ? answerDirection === "definition"
        ? currentCard.term
        : currentCard.definition
      : "";

  const correctAnswer =
    currentCard
      ? answerDirection === "definition"
        ? currentCard.definition
        : currentCard.term
      : "";

  const options = useMemo(() => {
    if (!currentCard) {
      return [];
    }

    return buildOptions(
      currentCard,
      cards,
      answerDirection
    );
  }, [
    currentCard,
    cards,
    answerDirection,
  ]);

  const durationForRound = (index) => Math.max(2500, baseTime * 1000 - (speedUp ? index * 120 : 0));
  const roundDuration = durationForRound(currentIndex);

  function stopRoundTimer() {
    if (timerRef.current) {
      window.clearInterval(timerRef.current);
      timerRef.current = null;
    }
  }

  function startRoundTimer(duration) {
    stopRoundTimer();

    const startedAt = Date.now();
    roundStartedRef.current = startedAt;

    setTimeLeft(duration);

    timerRef.current = window.setInterval(() => {
      const elapsed = Date.now() - startedAt;
      const remaining = Math.max(
        0,
        duration - elapsed
      );

      setTimeLeft(remaining);

      if (remaining <= 0) {
        stopRoundTimer();
        handleTimeout();
      }
    }, 50);
  }

  function startGame() {
    if (cards.length < 2) {
      return;
    }

    const newQueue = shuffle(cards);

    setQueue(newQueue);
    setCurrentIndex(0);

    setScore(0);
    setCombo(0);
    setBestCombo(0);

    setLives(startingLives);

    setCorrectCount(0);
    setWrongCount(0);

    setFeedbackId(null);
    setFeedbackType(null);

    setLocked(false);

    setGameOver(false);
    setGameStarted(true);

    window.setTimeout(() => {
      startRoundTimer(durationForRound(0));
    }, 100);
  }

  function nextQuestion() {
    const nextIndex = currentIndex + 1;

    if (nextIndex >= queue.length) {
      const reshuffled = shuffle(cards);

      setQueue(reshuffled);
      setCurrentIndex(0);

      window.setTimeout(() => {
        startRoundTimer(
          durationForRound(nextIndex)
        );
      }, betweenQuestions);

      return;
    }

    setCurrentIndex(nextIndex);

    window.setTimeout(() => {
      startRoundTimer(
        durationForRound(nextIndex)
      );
    }, betweenQuestions);
  }

  function endGame() {
    stopRoundTimer();
    setGameOver(true);
    setLocked(true);
  }

  function loseLife() {
    setLives((currentLives) => {
      const nextLives = currentLives - 1;

      if (nextLives <= 0) {
        window.setTimeout(() => {
          endGame();
        }, 450);
      }

      return Math.max(0, nextLives);
    });
  }

  function handleTimeout() {
    if (locked || gameOver) {
      return;
    }

    setLocked(true);
    setFeedbackType("timeout");
    setCombo(0);
    setWrongCount((value) => value + 1);

    loseLife();

    window.setTimeout(() => {
      if (!gameOver) {
        setFeedbackType(null);
        setLocked(false);

        nextQuestion();
      }
    }, betweenQuestions);
  }

  async function handleAnswer(option, index) {
    if (
      locked ||
      gameOver ||
      !currentCard
    ) {
      return;
    }

    stopRoundTimer();
    setLocked(true);

    const isCorrect =
      normalize(option) ===
      normalize(correctAnswer);

    const saved = await saveReview(currentCard, isCorrect, "multiple", option, { questionKey: `blast-${currentIndex}-${roundStartedRef.current}` });
    if (!saved) {
      setLocked(false);
      return;
    }

    setFeedbackId(index);

    if (isCorrect) {
      setFeedbackType("correct");

      const nextCombo = combo + 1;

      setCombo(nextCombo);

      setBestCombo((value) =>
        Math.max(value, nextCombo)
      );

      const multiplier =
        1 + Math.floor(nextCombo / 3) * 0.25;

      const speedBonus =
        Math.round(timeLeft / 100);

      const points =
        Math.round(
          (100 + speedBonus) * multiplier
        );

      setScore(
        (value) => value + points
      );

      setCorrectCount(
        (value) => value + 1
      );

      window.setTimeout(() => {
        setFeedbackId(null);
        setFeedbackType(null);
        setLocked(false);

        nextQuestion();
      }, betweenQuestions);

      return;
    }

    setFeedbackType("wrong");

    setCombo(0);

    setWrongCount(
      (value) => value + 1
    );

    loseLife();

    window.setTimeout(() => {
      if (!gameOver) {
        setFeedbackId(null);
        setFeedbackType(null);
        setLocked(false);

        nextQuestion();
      }
    }, betweenQuestions);
  }

  if (!mounted) {
    return (
      <section className="study-shell">
        <div className="empty-state">
          <p>Loading Blast...</p>
        </div>
      </section>
    );
  }

  if (cards.length < 2) {
    return (
      <section className="study-shell">
        <div className="empty-state">
          <h2>Blast needs more cards</h2>

          <p>
            Add at least two cards to this deck before
            starting Blast.
          </p>
        </div>
      </section>
    );
  }

  if (!gameStarted) {
    return (
      <section className="study-shell blast-game">
        <div className="study-header">
          <div>
            <p className="eyebrow">
              Game mode
            </p>

            <h1>Blast</h1>

            <p>
              Answer quickly, build your combo, and survive
              as the rounds get faster.
            </p>
          </div>
        </div>

        <section className="editor-panel blast-setup">
          <h2>Answer with</h2>

          <div className="direction-toggle">
            <button
              type="button"
              className={
                answerDirection === "definition"
                  ? "button primary"
                  : "button"
              }
              onClick={() =>
                setAnswerDirection("definition")
              }
            >
              Definitions
            </button>

            <button
              type="button"
              className={
                answerDirection === "term"
                  ? "button primary"
                  : "button"
              }
              onClick={() =>
                setAnswerDirection("term")
              }
            >
              Terms
            </button>
          </div>

          <div className="blast-rules">
            <span>{startingLives} lives</span>
            <span>{speedUp ? "Faster every round" : "Steady timer"}</span>
            <span>Combo score multiplier</span>
          </div>

          <div className="blast-customize-grid">
            <label>Seconds per question<select value={baseTime} onChange={(event) => setBaseTime(Number(event.target.value))}><option value="6">6 seconds</option><option value="8">8 seconds</option><option value="10">10 seconds</option><option value="15">15 seconds</option><option value="20">20 seconds</option></select></label>
            <label>Pause after each answer<select value={betweenQuestions} onChange={(event) => setBetweenQuestions(Number(event.target.value))}><option value="400">Quick — 0.4s</option><option value="900">Normal — 0.9s</option><option value="1500">Relaxed — 1.5s</option><option value="2500">Study pace — 2.5s</option></select></label>
            <label>Lives<select value={startingLives} onChange={(event) => setStartingLives(Number(event.target.value))}><option value="1">1 life</option><option value="3">3 lives</option><option value="5">5 lives</option><option value="10">10 lives</option></select></label>
            <label className="blast-toggle"><input type="checkbox" checked={speedUp} onChange={(event) => setSpeedUp(event.target.checked)} /> Speed up each round</label>
          </div>

          <button
            className="button primary"
            type="button"
            onClick={startGame}
          >
            Start Blast
          </button>
        </section>
      </section>
    );
  }

  if (gameOver) {
    const totalAnswers =
      correctCount + wrongCount;

    const accuracy =
      totalAnswers > 0
        ? Math.round(
            (correctCount / totalAnswers) * 100
          )
        : 0;

    return (
      <section className="study-shell blast-game">
        <div className="empty-state blast-results">
          <p className="eyebrow">
            Game over
          </p>

          <h1>{score} points</h1>

          <div className="metrics-strip small">
            <div>
              <span>{correctCount}</span>
              <p>Correct</p>
            </div>

            <div>
              <span>{accuracy}%</span>
              <p>Accuracy</p>
            </div>

            <div>
              <span>{bestCombo}x</span>
              <p>Best combo</p>
            </div>
          </div>

          <div className="row-actions">
            <button
              className="button primary"
              type="button"
              onClick={startGame}
            >
              Play again
            </button>

            <button
              className="button"
              type="button"
              onClick={() => {
                setGameStarted(false);
                setGameOver(false);
              }}
            >
              Back to setup
            </button>
          </div>
        </div>
      </section>
    );
  }

  const progress =
    roundDuration > 0
      ? Math.max(
          0,
          Math.min(
            100,
            (timeLeft / roundDuration) * 100
          )
        )
      : 0;

  return (
    <section className="study-shell blast-game">
      <XpNotice notice={xpNotice} />
      <div className="blast-hud">
        <div>
          <span className="blast-hud-label">
            Score
          </span>

          <strong>{score}</strong>
        </div>

        <div>
          <span className="blast-hud-label">
            Combo
          </span>

          <strong>{combo}x</strong>
        </div>

        <div>
          <span className="blast-hud-label">
            Lives
          </span>

          <strong>
            {"♥".repeat(lives)}
            {"♡".repeat(startingLives - lives)}
          </strong>
        </div>
      </div>

      <div className="blast-time-track">
        <div
          className="blast-time-fill"
          style={{
            width: `${progress}%`,
          }}
        />
      </div>

      <section className="blast-question-card">
        <p className="eyebrow">
          Blast
        </p>

        <h1>{prompt}</h1>

        {feedbackType === "timeout" ? (
          <div className="blast-feedback timeout">
            Too slow!
          </div>
        ) : null}
      </section>

      <div className="blast-target-grid">
        {options.map((option, index) => {
          let className = "blast-target";

          if (
            feedbackId === index &&
            feedbackType === "correct"
          ) {
            className += " blast-target-correct";
          }

          if (
            feedbackId === index &&
            feedbackType === "wrong"
          ) {
            className += " blast-target-wrong";
          }

          return (
            <button
              key={`${option}-${index}`}
              type="button"
              className={className}
              disabled={locked}
              onClick={() =>
                handleAnswer(option, index)
              }
            >
              <span>
                {option}
              </span>
            </button>
          );
        })}
      </div>

      <div className="blast-footer">
        <span>
          {correctCount} correct
        </span>

        <span>
          Round {currentIndex + 1}
        </span>

        <span>
          {Math.ceil(timeLeft / 1000)}s
        </span>
      </div>
    </section>
  );
}
